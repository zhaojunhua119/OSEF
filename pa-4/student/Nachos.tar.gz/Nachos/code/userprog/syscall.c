//#include "syscall.h"
//#include "sysdep.h"
///* Read "size" bytes from the open file into "buffer".
// * Return the number of bytes actually read -- if the open file isn't
// * long enough, or if it is an I/O device, and there aren't enough
// * characters to read, return whatever is available (for I/O devices,
// * you should always wait until you can return at least one character).
// */
//int Read(char *buffer, int size, OpenFileId id) {
//	if (id == CONSOLEINPUT) {
//
//	}
//}
