tinyshell> chdir: No such file or directory
An error has occurred
tinyshell> An error has occurred
tinyshell> excevp: No such file or directory
An error has occurred
tinyshell> 